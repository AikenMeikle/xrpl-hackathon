"""Feature engineering for the Decode & Detect hackathon.

Design rules:
  * never use a wallet address (or anything derived from its identity) as a feature;
  * prefer counts, ratios, timings and flow shapes over absolute amounts, so the
    model survives the test set's different batch sizes and currencies;
  * everything is vectorised: the whole week of payments is processed in seconds.
"""
import numpy as np
import pandas as pd

SHIFT = np.int64(1) << np.int64(34)
MINUTE, HOUR, DAY = 60, 3600, 86400


class EventIndex:
    """'What did this wallet do near time t?' answered for every payment at once.

    Events are sorted by (wallet, time) and addressed with the composite key
    wallet * 2**34 + time, so a window query is two np.searchsorted calls.
    """

    def __init__(self, wallet, time, value, row, novel=None):
        order = np.lexsort((time, wallet))
        self.w = np.asarray(wallet)[order]
        self.t = np.asarray(time)[order].astype(np.int64)
        self.v = np.asarray(value)[order].astype(float)
        self.row = np.asarray(row)[order]
        self.key = self.w.astype(np.int64) * SHIFT + self.t
        self.cum_v = np.concatenate([[0.0], np.cumsum(self.v)])
        novel = np.ones(len(self.w)) if novel is None else np.asarray(novel)[order]
        self.cum_n = np.concatenate([[0.0], np.cumsum(novel)])
        self.n = len(self.w)

    def _lo(self, w, t):
        t = np.maximum(np.asarray(t, dtype=np.int64), 0)
        return np.searchsorted(self.key, np.asarray(w).astype(np.int64) * SHIFT + t, "left")

    def _hi(self, w, t):
        t = np.maximum(np.asarray(t, dtype=np.int64), 0)
        return np.searchsorted(self.key, np.asarray(w).astype(np.int64) * SHIFT + t, "right")

    def count(self, w, t, before, after):
        return (self._hi(w, t + after) - self._lo(w, t - before)).astype(float)

    def amount(self, w, t, before, after):
        return self.cum_v[self._hi(w, t + after)] - self.cum_v[self._lo(w, t - before)]

    def distinct(self, w, t, before, after):
        """Approximate number of distinct counterparties in the window."""
        return self.cum_n[self._hi(w, t + after)] - self.cum_n[self._lo(w, t - before)]

    def next_pos(self, w, t):
        idx = self._hi(w, t)
        safe = np.minimum(idx, max(self.n - 1, 0))
        ok = (idx < self.n) & (self.w[safe] == np.asarray(w))
        return np.where(ok, safe, -1)

    def prev_pos(self, w, t):
        idx = self._lo(w, t) - 1
        safe = np.maximum(idx, 0)
        ok = (idx >= 0) & (self.w[safe] == np.asarray(w))
        return np.where(ok, safe, -1)

    def _gather(self, arr, pos, default):
        safe = np.maximum(pos, 0)
        return np.where(pos >= 0, arr[safe], default)

    def time_at(self, pos, default=np.nan):
        return self._gather(self.t.astype(float), pos, default)

    def value_at(self, pos, default=np.nan):
        return self._gather(self.v, pos, default)

    def row_at(self, pos):
        return self._gather(self.row, pos, -1).astype(int)


def safe_div(a, b, fill=0.0):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    out = np.full(np.broadcast(a, b).shape, fill, dtype=float)
    return np.divide(a, b, out=out, where=b != 0)


def distinct_peers(group, other, n_groups):
    """Distinct `other` values per group id (array of length n_groups)."""
    pairs = np.unique(np.stack([np.asarray(group), np.asarray(other)], axis=1), axis=0)
    return np.bincount(pairs[:, 0], minlength=n_groups).astype(float)


def wallet_groups(src, dst, n_wallets, n_rows, hub=None, buckets=40, seed=0):
    """Union-find over wallets -> one group id per payment, for leak-free validation.

    Two payments that share a wallet (directly, or through a chain of wallets) land in
    the same group, so a grouped split never trains and validates on the same wallet.
    Hub wallets (exchange-like, huge degree) are left out of the merging, otherwise they
    would glue the entire ledger into one component. Any remaining giant component is
    sharded by sender wallet so the folds stay a usable size.
    """
    parent = np.arange(n_wallets)
    src, dst = np.asarray(src), np.asarray(dst)
    hub = np.zeros(n_wallets, dtype=bool) if hub is None else np.asarray(hub)

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for a, b in zip(src, dst):
        if hub[a] or hub[b]:
            continue
        ra, rb = find(int(a)), find(int(b))
        if ra != rb:
            parent[max(ra, rb)] = min(ra, rb)
    root = np.array([find(i) for i in range(n_wallets)])
    comp = pd.factorize(root)[0]
    row_comp = np.where(hub[src], comp[dst], comp[src])
    sizes = np.bincount(row_comp)
    giant = int(np.argmax(sizes))
    if sizes[giant] > 0.3 * n_rows:
        rng = np.random.default_rng(seed)
        shard = rng.integers(0, buckets, size=n_wallets)
        row_comp = np.where(row_comp == giant, comp.max() + 1 + shard[src], row_comp)
    return pd.factorize(row_comp)[0]


def build_features(df, seed=0):
    """Return (features DataFrame incl. TRANSACTION_HASH, group ids, {block: columns})."""
    df = df.sort_values(["TIMESTAMP", "TRANSACTION_HASH"], kind="mergesort").reset_index(drop=True)
    t = df.TIMESTAMP.astype(np.int64).to_numpy()
    value = df.VALUE.astype(float).to_numpy()
    n = len(df)
    rows = np.arange(n)

    codes = pd.factorize(pd.concat([df.FROM_ADDRESS, df.TO_ADDRESS], ignore_index=True))[0]
    src, dst = codes[:n], codes[n:]
    n_w = int(codes.max()) + 1

    # "novel counterparty" flag: first time this ordered pair transacts within 2h
    pair = src.astype(np.int64) * np.int64(n_w) + dst
    rpair = dst.astype(np.int64) * np.int64(n_w) + src
    pair_code, _ = pd.factorize(np.concatenate([pair, rpair]))
    pc, rc = pair_code[:n], pair_code[n:]
    pair_ev = EventIndex(pc, t, value, rows)
    prev_same_pair = pair_ev.prev_pos(pc, t)
    gap_same_pair = t - pair_ev.time_at(prev_same_pair, default=-1e9)
    novel_out = (gap_same_pair > 2 * HOUR).astype(float)

    out = EventIndex(src, t, value, rows, novel=novel_out)
    inn = EventIndex(dst, t, value, rows, novel=novel_out)

    f = pd.DataFrame({"TRANSACTION_HASH": df.TRANSACTION_HASH.to_numpy()})
    blocks, seen = {}, {"TRANSACTION_HASH"}

    def close(name):
        blocks[name] = [c for c in f.columns if c not in seen]
        seen.update(f.columns)

    # ---------------- 1. amount shape (deliberately scale-free) ----------------
    out_cnt = np.bincount(src, minlength=n_w).astype(float)
    in_cnt = np.bincount(dst, minlength=n_w).astype(float)
    out_usd = np.bincount(src, weights=value, minlength=n_w)
    in_usd = np.bincount(dst, weights=value, minlength=n_w)
    med_out = pd.Series(value).groupby(src).median().reindex(range(n_w)).fillna(0).to_numpy()
    med_in = pd.Series(value).groupby(dst).median().reindex(range(n_w)).fillna(0).to_numpy()

    f["amt_rank"] = pd.Series(value).rank(pct=True).to_numpy()
    f["amt_log"] = np.log1p(np.maximum(value, 0))
    f["amt_vs_sender_median"] = np.log1p(np.clip(safe_div(value, med_out[src]), 0, 100))
    f["amt_vs_receiver_median"] = np.log1p(np.clip(safe_div(value, med_in[dst]), 0, 100))
    dec = np.log10(np.maximum(value, 1e-9))
    f["amt_mantissa"] = dec - np.floor(dec)
    for base in (100, 1_000, 10_000):
        f[f"round_{base}"] = (np.abs(value / base - np.round(value / base)) < 0.01).astype(float)
    f["just_under_10k"] = ((value > 8_500) & (value < 10_000)).astype(float)
    sig2 = np.round(value / 10.0 ** np.floor(dec - 1)) * 10.0 ** np.floor(dec - 1)
    f["sender_repeats_amount"] = np.log1p(
        pd.Series(np.ones(n)).groupby([pd.Series(src), pd.Series(sig2)]).transform("size").to_numpy())
    close("amount")

    # ---------------- 2. per-wallet aggregates over the whole week ----------------
    peers_out = distinct_peers(src, dst, n_w)
    peers_in = distinct_peers(dst, src, n_w)
    tmin = pd.Series(t).groupby(src).min().reindex(range(n_w)).to_numpy()
    tmax = pd.Series(t).groupby(src).max().reindex(range(n_w)).to_numpy()
    span = np.nan_to_num(tmax - tmin, nan=0.0)

    for name, code in (("snd", src), ("rcv", dst)):
        f[f"{name}_n_out"] = np.log1p(out_cnt[code])
        f[f"{name}_n_in"] = np.log1p(in_cnt[code])
        f[f"{name}_usd_out"] = np.log1p(out_usd[code])
        f[f"{name}_usd_in"] = np.log1p(in_usd[code])
        f[f"{name}_peers_out"] = np.log1p(peers_out[code])
        f[f"{name}_peers_in"] = np.log1p(peers_in[code])
        f[f"{name}_io_count_ratio"] = safe_div(out_cnt[code], out_cnt[code] + in_cnt[code])
        f[f"{name}_io_usd_ratio"] = np.clip(safe_div(out_usd[code], in_usd[code]), 0, 5)
        f[f"{name}_reuse_out"] = safe_div(out_cnt[code], peers_out[code])
        f[f"{name}_reuse_in"] = safe_div(in_cnt[code], peers_in[code])
        f[f"{name}_active_days"] = span[code] / DAY
        f[f"{name}_per_day"] = safe_div(out_cnt[code], np.maximum(span[code], HOUR) / DAY)
    f["share_of_sender_out"] = safe_div(value, out_usd[src])
    f["share_of_receiver_in"] = safe_div(value, in_usd[dst])
    f["size_gap"] = np.log1p(out_cnt[src] + in_cnt[src]) - np.log1p(out_cnt[dst] + in_cnt[dst])
    close("wallet")

    # ---------------- 3. timing, velocity, bursts ----------------
    for name, code in (("snd", src), ("rcv", dst)):
        for win, wname in ((MINUTE, "1m"), (10 * MINUTE, "10m"), (HOUR, "1h"), (6 * HOUR, "6h")):
            f[f"{name}_sent_{wname}"] = np.log1p(out.count(code, t, win, win))
            f[f"{name}_recv_{wname}"] = np.log1p(inn.count(code, t, win, win))

    nxt = out.next_pos(dst, t)          # receiver's next outgoing payment
    prv = inn.prev_pos(src, t)          # sender's previous incoming payment
    gap_fwd = out.time_at(nxt) - t
    gap_bwd = t - inn.time_at(prv)
    fwd_amt = out.value_at(nxt, default=0.0)
    bwd_amt = inn.value_at(prv, default=0.0)

    f["secs_to_forward"] = np.log1p(np.nan_to_num(gap_fwd, nan=7 * DAY))
    f["secs_since_funded"] = np.log1p(np.nan_to_num(gap_bwd, nan=7 * DAY))
    f["forwards_within_1h"] = (np.nan_to_num(gap_fwd, nan=1e9) < HOUR).astype(float)
    f["funded_within_1h"] = (np.nan_to_num(gap_bwd, nan=1e9) < HOUR).astype(float)
    f["forward_amount_ratio"] = np.clip(safe_div(fwd_amt, value), 0, 3)
    f["funded_amount_ratio"] = np.clip(safe_div(value, bwd_amt), 0, 3)
    f["forward_similar"] = (np.abs(f.forward_amount_ratio - 1) < 0.15).astype(float)
    f["funded_similar"] = (np.abs(f.funded_amount_ratio - 1) < 0.15).astype(float)
    f["rcv_in_usd_1h"] = np.log1p(inn.amount(dst, t, HOUR, HOUR))
    f["rcv_out_usd_1h"] = np.log1p(out.amount(dst, t, HOUR, HOUR))
    f["snd_in_usd_1h"] = np.log1p(inn.amount(src, t, HOUR, HOUR))
    f["flow_through_1h"] = np.clip(
        safe_div(out.amount(dst, t, 0, HOUR), inn.amount(dst, t, HOUR, 0) + value), 0, 3)
    f["flow_through_24h"] = np.clip(
        safe_div(out.amount(dst, t, 0, DAY), inn.amount(dst, t, DAY, 0) + value), 0, 3)

    hod = (t % DAY) / DAY
    f["hour_sin"], f["hour_cos"] = np.sin(2 * np.pi * hod), np.cos(2 * np.pi * hod)
    f["is_night"] = ((hod < 0.25) | (hod > 0.92)).astype(float)
    f["is_weekend"] = (((t // DAY + 4) % 7) >= 5).astype(float)
    close("timing")

    # ---------------- 4. graph structure: fan in/out, reuse, round trips, triangles ----
    pair_total = pd.Series(pair).map(pd.Series(pair).value_counts()).to_numpy().astype(float)
    pair_seq = pd.Series(pair).groupby(pair).cumcount().to_numpy()
    edge_set = set(np.unique(pair).tolist())
    f["edge_payments"] = np.log1p(pair_total)
    f["edge_first_time"] = (pair_seq == 0).astype(float)
    f["edge_seen_before"] = np.log1p(pair_seq)
    f["edge_share_of_sender"] = safe_div(pair_total, out_cnt[src])
    f["edge_reciprocated"] = np.isin(rpair, list(edge_set)).astype(float)
    f["round_trip_24h"] = (pair_ev.count(rc, t, 0, DAY) > 0).astype(float)
    f["round_trip_prior_24h"] = (pair_ev.count(rc, t, DAY, 0) > 0).astype(float)

    f["fan_out_10m"] = np.log1p(out.distinct(src, t, 10 * MINUTE, 10 * MINUTE))
    f["fan_in_10m"] = np.log1p(inn.distinct(dst, t, 10 * MINUTE, 10 * MINUTE))
    f["fan_out_1h"] = np.log1p(out.distinct(src, t, HOUR, HOUR))
    f["fan_in_1h"] = np.log1p(inn.distinct(dst, t, HOUR, HOUR))
    f["rcv_fanout_next_1h"] = np.log1p(out.distinct(dst, t, 0, HOUR))
    f["snd_fanin_prev_1h"] = np.log1p(inn.distinct(src, t, HOUR, 0))
    f["smurf_shape"] = safe_div(out.distinct(dst, t, 0, HOUR), inn.distinct(dst, t, HOUR, 0) + 1)

    tri = np.zeros(n_w)
    edges = pd.DataFrame({"a": src, "b": dst}).drop_duplicates()
    hub = (peers_out > 200) | (peers_in > 200)
    edges = edges[~hub[edges.a.to_numpy()] & ~hub[edges.b.to_numpy()]]
    if 0 < len(edges) < 500_000:
        two = edges.merge(edges, left_on="b", right_on="a", suffixes=("", "_2"))
        if len(two) < 4_000_000:
            closes = np.isin(two.b_2.to_numpy().astype(np.int64) * n_w + two.a.to_numpy(),
                             list(edge_set))
            tri_rows = two[closes]
            tri = np.bincount(np.concatenate([tri_rows.a.to_numpy(), tri_rows.b.to_numpy(),
                                              tri_rows.b_2.to_numpy()]), minlength=n_w).astype(float)
    f["snd_triangles"] = np.log1p(tri[src])
    f["rcv_triangles"] = np.log1p(tri[dst])
    close("graph")

    # ---------------- 5. layering chains across several hops ----------------
    hop_row = out.row_at(nxt)
    hop_dt = np.nan_to_num(gap_fwd, nan=1e9)
    hop_ratio = safe_div(fwd_amt, value)
    good_hop = (hop_dt < 6 * HOUR) & (hop_ratio > 0.5) & (hop_ratio < 1.05)

    def walk(start_row, ok_mask, steps=6):
        length = np.zeros(n)
        cur = np.where(ok_mask, start_row, -1)
        for _ in range(steps):
            live = cur >= 0
            if not live.any():
                break
            length += live
            idx = np.maximum(cur, 0)
            cur = np.where(live & ok_mask[idx], start_row[idx], -1)
        return length

    f["chain_forward_hops"] = walk(hop_row, good_hop)

    back_row = inn.row_at(prv)
    back_dt = np.nan_to_num(gap_bwd, nan=1e9)
    back_ratio = safe_div(value, bwd_amt)
    good_back = (back_dt < 6 * HOUR) & (back_ratio > 0.5) & (back_ratio < 1.05)
    f["chain_back_hops"] = walk(back_row, good_back)
    f["chain_total_hops"] = f.chain_forward_hops + f.chain_back_hops
    f["chain_is_middle"] = ((f.chain_forward_hops > 0) & (f.chain_back_hops > 0)).astype(float)
    close("chains")

    # ---------------- 6. neighbourhood: the company a wallet keeps ----------------
    pass_through = np.clip(safe_div(out_usd, in_usd), 0, 3)
    hold = pd.Series(np.nan_to_num(gap_fwd, nan=7 * DAY)).groupby(dst).median() \
             .reindex(range(n_w)).fillna(7 * DAY).to_numpy()
    activity = np.log1p(out_cnt + in_cnt)
    for name, code in (("snd", src), ("rcv", dst)):
        f[f"{name}_pass_through"] = pass_through[code]
        f[f"{name}_median_hold"] = np.log1p(hold[code])
    f["snd_peers_pass_through"] = safe_div(
        np.bincount(src, weights=pass_through[dst], minlength=n_w), out_cnt)[src]
    f["rcv_peers_pass_through"] = safe_div(
        np.bincount(dst, weights=pass_through[src], minlength=n_w), in_cnt)[dst]
    f["snd_peers_activity"] = safe_div(
        np.bincount(src, weights=activity[dst], minlength=n_w), out_cnt)[src]
    f["rcv_peers_activity"] = safe_div(
        np.bincount(dst, weights=activity[src], minlength=n_w), in_cnt)[dst]
    f["chain_pressure"] = f.snd_pass_through * f.rcv_pass_through
    close("neighbourhood")

    feats = f.drop(columns="TRANSACTION_HASH").astype(float)
    feats = feats.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    feats.insert(0, "TRANSACTION_HASH", f.TRANSACTION_HASH.to_numpy())
    degree = peers_out + peers_in
    hub = degree >= max(50, np.quantile(degree, 0.995))
    groups = wallet_groups(src, dst, n_w, n, hub=hub, seed=seed)
    return feats, groups, blocks
